#include <iostream>
#include <string>
#include <cassert>
using namespace std;

int appendToAll(string a[], int n, string value);	
int lookup(const string a[], int n, string target);
int positionOfMax(const string a[], int n);
int rotateLeft(string a[], int n, int pos);
int countRuns(const string a[], int n);
int flip(string a[], int n);
int differ(const string a1[], int n1, const string a2[], int n2);
int subsequence(const string a1[], int n1, const string a2[], int n2);
int lookupAny(const string a1[], int n1, const string a2[], int n2);
int separate(string a[], int n, string separator);

int main()
{
	string h[7] = { "mick", "marie", "fiona", "rudy", "", "gordon", "lindsey" };
	assert(lookup(h, 7, "gordon") == 5);
	assert(lookup(h, 7, "fiona") == 2);
	assert(lookup(h, 2, "fiona") == -1);
	assert(positionOfMax(h, 7) == 3);

	string g[4] = { "mick", "marie", "lindsey", "nancy" };
	assert(differ(h, 4, g, 4) == 2);
	assert(appendToAll(g, 4, "?") == 4 && g[0] == "mick?" && g[3] == "nancy?");
	assert(rotateLeft(g, 4, 1) == 1 && g[1] == "lindsey?" && g[3] == "marie?");

	string e[4] = { "fiona", "rudy", "", "gordon" };
	assert(subsequence(h, 7, e, 4) == 2);

	string d[5] = { "marie", "marie", "marie", "rudy", "rudy" };
	assert(countRuns(d, 5) == 2);

	string f[3] = { "lindsey", "fiona", "mike" };
	assert(lookupAny(h, 7, f, 3) == 2);
	assert(flip(f, 3) == 3 && f[0] == "mike" && f[2] == "lindsey");

	assert(separate(h, 7, "lindsey") == 3);

	cout << "All tests succeeded" << endl;
}

int appendToAll(string a[], int n, string value) 
{
	if (n < 0)
		return -1; // No negative size

	for (int i = 0; i < n; i++) // Appened at every array element
		a[i] += value;
	
	return n;
}

int lookup(const string a[], int n, string target)
{
	if (n < 0) // No negative size
		return -1;

	for (int i = 0; i < n; i++) // Compare every array element to target and return earliest position
	{
		if (a[i] == target)
			return i;
	}

	return -1;
}

int positionOfMax(const string a[], int n)
{
	if (n <= 0) // No negative size, 0 included because returning 0 implies max pos at 0, which is wrong
		return -1;

	int pos = 0;
	string str = a[0]; 
	for (int i = 1; i < n; i++) // Compare to initial element, then check every element if greater, if it is, replace str
	{
		if (a[i] > str)
		{
			pos = i;
			str = a[i];
		}
	}
	return pos;
}

int rotateLeft(string a[], int n, int pos)
{
	if ((n <= 0) || (pos >= n) || (pos < 0)) // If n is 0, can't locate pos, same if pos is greater than or equal to n, pos also can't be negative
		return -1;
	
	string str = a[pos];
	for (int i = pos; i < n-1; i++) // Start at position in question, replace with next element, if detects last element replace with initial element
	{
		a[i] = a[i + 1];
		if (i + 1 == n - 1)
			a[i + 1] = str;		
	}
	return pos;
}

int countRuns(const string a[], int n) 
{
	if (n < 0)
		return -1;
	if (n == 0) // If no elements are inspected, there are no consecutive elements
		return 0;

	int count = 1;
	for (int i = 0; i < n - 1; i++) // Measure start of run
	{
		for (int j = i + 1; j < n; j++) // Measure how long the run continues
		{	
			if (a[i] == a[j])
				continue;
			else // If the run stops, then add 1, accounting for the new element by adding 1 to count
			{
				count++;
				i = j - 1;
				break;
			}
		}
	}
	return count;
}

int flip(string a[], int n) 
{
	if (n < 0)
		return -1;

	int r = n - 1;
	for (int i = 0; i <= ((n-1) / 2); i++) // Only loop through half of array elements, r is last element of interest, swap and iterate going up and down array
	{
		string dummy = a[i];
		a[i] = a[r];
		a[r] = dummy;
		r--;
	}
	return n; // Return 0 if n is 0, no elements inspected means no elements flipped
}

int differ(const string a1[], int n1, const string a2[], int n2)
{
	if ((n1 < 0) || (n2 < 0)) // 0 means the point at which they are equal does not occur, and runs out immediately
		return -1;

	int size = 0;
	if (n1 <= n2) // Set size for loop using the smaller n value
		size = n1;
	else
		size = n2;

	for (int i = 0; i < size; i++) // Iterate through to find the differing position, then return the position
	{
		if (a1[i] != a2[i])
			return i;
	}
	return size; // If no difference in the elements presented, return smaller n value
}

int subsequence(const string a1[], int n1, const string a2[], int n2) 
{
	if ((n1 < 0) || (n2 < 0) || (n2 > n1)) // n2 cannot be greater than n1 because then it would be impossible for the subsequence to exist in the sequence
		return -1;
	if (n2 == 0) // Since 0 is a subsequence of any sequence, even 0, then the subsequence would always occur at position 0, so return 0
		return 0;
	
	for (int i = 0; i <= (n1-n2); i++) // n1 - n2 measures the max position at which the subsequence could start
	{
		int d = i;
		for (int j = 0; j < n2; j++)
		{
			if (a1[d] == a2[j])
			{
				if (j == (n2 - 1)) // Detects if the last subsequence value was equal
					return i;
				else
				{
					d++;
					continue; // j and d both increase by 1 after next loop
				}
			}
			break; // If the first possible values don't match, break because there is no need to keep going, it also prevents a sub-subsequence match error
		}
	}
	return -1; // No matching subsequence in the sequence
}

int lookupAny(const string a1[], int n1, const string a2[], int n2)
{
	if ((n1 <= 0) || (n2 <= 0)) // If n1 were 0, then no matching elements so return -1, and same with n2
		return -1;

	for (int i = 0; i < n1; i++) // For every a1 value look through a2 elements and see if any match up, then return the position of that a1 element
	{
		for (int j = 0; j < n2; j++)
		{
			if (a1[i] == a2[j])
				return i;
		}
	}
	return -1; // No matches
}

int separate(string a[], int n, string separator) 
{
	if (n < 0) // If n were 0, nothing would be separated and can't return a valid position, so return -1
		return -1;

	int t = 0;
	for (int i = 0; i < n; i++) // Sort through and find elements that are less than separator, moving them leftmost by swapping values with ones that aren't less than separator
	{
		if (a[i] < separator)
		{
			string dummy = a[t];
			a[t] = a[i];
			a[i] = dummy;
			t++;
		}
	}
	int t1 = t;
	for (int i = t1; i < n; i++) // Iterate through to find all elements that equal separator after all elements less than separator
	{
		if (a[i] == separator)
		{
			string dummy = a[t1];
			a[t1] = a[i];
			a[i] = dummy;
			t1++;
		}
	}
	return t; // Returns n if all elements are less than separator, which would be t + 1
}