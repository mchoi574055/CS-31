#include <iostream>
#include <string>
using namespace std;
int main()
{
	// Get Defendant name
	cout << "Defendant: "; 
		string defendant = ""; 
			getline(cin, defendant); 

	// Get amount paid in thousands (can be double)
	cout << "Amount paid (in thousands): "; 
		double paid = 0; 
			cin >> paid;
				cin.ignore(1000, '\n'); // Negating the line created when pressing enter to get string for "fake"
	
	// Get whether or not an athlete was faked
	cout << "Fake athlete? (y/n): ";
		string fake = ""; 
			getline(cin, fake); 

	// Creates line for last text
	cout << "---" << endl; 

	// Flat 20 thousand fee imposed
	double fine = 20; 

	// Triggers if no text is typed in for name
	if (defendant == "")
		cout << "You must enter a defendant name." << endl; 

	// Triggers if paid is not positive or not 0
	else if (paid < 0)
		cout << "The amount paid must not be negative." << endl; 

	// Triggers if a letter other than y or n is typed in, such as Y or s
	else if ((fake != "y") && (fake != "n"))
		cout << "You must enter y or n." << endl; 

	else 
	{
		// Bribes over 250 thousand
		if (paid > 250)
		{
			fine += ((paid-250) * .14); 
			paid=250; // Different fines for rest of the 250 thousand
		}
		// Bribes under or equal to 250 thousand and over 40 thousand
		if (paid <= 250 && paid>40) 
		{
			if (fake == "y")
				fine += ((paid - 40) * .22); 
			else
				fine += ((paid - 40) * .1); 

			paid = 40; // Remaining fine for bribes at 40 thousand or under
		}

		// Bribes equal to or under 40 thousand
		fine += (paid * .66); 

		cout.setf(ios::fixed); 
		cout.precision(1); 

		// Display fine with one number right of decimal point and no scientific notation
		cout << "The suggested fine for " << defendant << " is $" << fine << " thousand." << endl;
	}
}