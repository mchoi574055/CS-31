#pragma warning(disable:6262)
#define _CRT_SECURE_NO_DEPRECATE
#include "utilities.h"
#include <iostream>	
#include <cctype>
#include <cstring>
using namespace std;

const char WORDFILENAME[] = "C:/Users/micha/Desktop/words.txt";
int playOneRound(const char words[][7], int nWords, int wordnum);


	int main()
	{
		char wordList[9000][7];
		int scores = 0;
		int n = getWords(wordList, 9000, WORDFILENAME);
		double sum = 0; // For average
		int min = 1; // Min 1 attempt, Max get it in 1 try
		int max = 1;
		
		if (n < 1) // n shows words loaded, must be at least 1 to play the game
		{
			cout << "No words were loaded, so I can't play the game.";
			return -1;
		}

		cout << "How many rounds do you want to play? ";
			int rounds = 0;
			cin >> rounds;
			cin.ignore(1000, '\n'); // Ignore the line generated for when user inputs the first trial word
			cout.precision(2); // 2 decimal points shown for accuracy for average
			cout.setf(ios::fixed); // For large values of average, maintain decimal point form
		
			if (rounds > 0)
				for (int i = 1; i <= rounds; i++)
				{	
					int wordnum = randInt(0, n - 1); // Generate random word location from wordnum 0 to position of max words generated - 1
					cout << '\n' << "Round " << i << endl;
					cout << "The mystery word is " << strlen(wordList[wordnum]) << " letters long." << endl;

					scores = playOneRound(wordList, n, wordnum);
					if (scores == 1)
						cout << "You got it in 1 try." << endl; // Different response for 1 correct guess
					else
						cout << "You got it in " << scores << " tries." << endl;
					
					if (i == 1) // Only one round played
					{
						min = scores;
						max = scores;
					}
					sum += scores;
					cout << "Average: " << (sum) / (i) << ", "; // Change the average to a double from two ints in calculation
					if (scores < min)
						min = scores;
					if (scores > max)
						max = scores;
					cout << "minimum: " << min << ", " << "maximum: " << max << endl;

				}
			else
				cout << "The number of rounds must be positive."; // If rounds is not greater than 0

	}

	int playOneRound(const char words[][7], int nWords, int wordnum)
	{
		if ((nWords <= 0) || (wordnum < 0) || (wordnum >= nWords)) // If there are no words in array, or less than 0, or if there is an attempt to access a position less than 0, or a position that is not initialized with a word
			return -1;

		char input[100];
		int score = 0;

		for (;;)
		{
			bool inArray = false;
			bool fourtosixlowercase = true;
			int positionsi[6] = { -1, -1, -1, -1, -1, -1 };
			int positionsw[6] = { -1, -1, -1, -1, -1, -1 };
			int posi = 0;
			int posw = 0;
			int flowers = 0;
			int bees = 0;

			cout << "Trial word: ";	
			cin.getline(input, 100);

			if (input[0] == '\0')
				fourtosixlowercase = false;

			for (int i = 0; i < strlen(input); i++) // Find if the user input a c string that is less than 4 characters long, longer than 6 characters, or not all lowercase letters
			{
				if ((strlen(input) < 4) || (strlen(input) > 6) || (!islower(input[i])))
				{
					fourtosixlowercase = false;
					break;
				}
			}
				if (fourtosixlowercase == false)
				{
					cout << "Your trial word must be a word of 4 to 6 lower case letters." << endl;
					continue;
				}

			for (int i = 0; i < nWords; i++) // Find if the c string the user input is a valid word in the array
			{
				if (strcmp(input, words[i]) == 0)
				{
					inArray = true;
					break;
				}
			}
				if (inArray == false)
				{
					cout << "I don't know that word." << endl;
					continue;
				}


			if (strcmp(input, words[wordnum]) == 0) // If the user guessed the word correctly, return the score + 1 (counts as an attempt)
			{
				score++;
				return score;
			}
			

			for (int i = 0, j = 0; (i < strlen(input)) && (j < strlen(words[wordnum])); i++, j++) // Find all the flowers in the user input and the word of interest
			{
				if (input[i] == words[wordnum][j])
				{
					flowers++;
					positionsi[posi] = i; // Use these array positions to ensure that the positions will not be examined again
					positionsw[posw] = j;
					posi++;
					posw++;
				}
			}

			for (int i = 0; i < strlen(input); i++) // Start the comparison by iterating along the user input c string
			{
				for (int j = 0; j < strlen(words[wordnum]); j++) // Compare with word of interest
				{
					bool overlap = false;
					for (int k = 0; k < posi; k++)
					{
						if ((positionsi[k]) == i) // If the position of user input has already been examined through a flower
							overlap = true;
					}
					for (int k = 0; k < posw; k++)
					{
						if ((positionsw[k] == j)) // If the position of word of interest has already been examined and was a match with flower/bee
							overlap = true;
					}
					if (overlap == true)
						continue; // If examined a position that has already been examined, move on to next position in word of interest

					else
					{
						if (input[i] == words[wordnum][j]) // If the character of user input matches word of interest, it is a bee
						{
							bees++;
							positionsw[posw] = j; // Add this position to the array so that it will not be examined again
							posw++;
							break;
						}
					}
				}
			}
			cout << "Flowers: " << flowers << ", Bees: " << bees << endl;
			score++; // User failed to guess word of interest correctly, add 1 to score
		}
	}
