#include "grid.h"
#include <cctype>
#include <iostream>
#include <cassert>
#include <string>
using namespace std;

const int HORIZ = 0;
const int VERT = 1;

const int FG = 0;
const int BG = 1;

bool plotLine(int r, int c, int distance, int dir, char plotChar, int fgbg);
int performCommands(string commandString, char& plotChar, int& mode, int& badPos);



int main()
{
	// Initialize grid size
	setSize(20, 30);

	// Starting parameters
	char currentChar = '*';
	int currentMode = FG;

	for (;;)
	{
		cout << "Enter a command string: ";
		string cmd;
		getline(cin, cmd);

		// Breaks loop if no characters are detected
		if (cmd == "")
			break;
		int position;
		int status = performCommands(cmd, currentChar, currentMode, position);
		switch (status)
		{
		// Works fine
		case 0:
			draw();
			break;
		// Command cannot be fully run because of a syntax error
		case 1:
			cout << "Syntax error at position " << position + 1 << endl;
			break;
		// Command cannot be fully run because one of the plotLine commands exceeds grid boundaries
		case 2:
			cout << "Cannot perform command at position " << position + 1 << endl;
			break;
		default:
			// It should be impossible to get here.
			cerr << "performCommands returned " << status << "!" << endl;
		}
	}
}

bool plotLine(int r, int c, int distance, int dir, char plotChar, int fgbg)
{
	// Increments depending on distance value (negative to positive increment and vice versa)
	int d = 0;
	if (distance * -1 < 0)
		d = -1;
	else if (distance != 0)
		d = 1;

	// If direction is neither horizontal nor vertical
	if (!(dir == 0 || dir == 1))
		return false;
	// If foreground/background does not have a valid value
	else if (!(fgbg == 0 || fgbg == 1))
		return false;
	// Detects if the plotLine exceeds grid boundaries, (0,0) is considered exceeding
	else if ((dir == 0) && (c + distance<=0 || c + distance>getCols()))
		return false;
	else if ((dir == 1) && (r + distance<=0 || r + distance>getRows()))
		return false;
	// If the character is valid and printable
	else if (!isprint(plotChar))
		return false;
	// If distance is 0, plot the row and column given without any other characters
	else if ((distance == 0) && (fgbg == 0 || getChar(r, c) == ' '))
	{
		setChar(r, c, plotChar);
		return true;
	}

	else
	{
		// Horizontal line plot
		if (dir == 0)
		{
			for (int i = c + distance; i != c; i += d) // Plots left to right if distance is negative, and right to left if distance is positve
			{
				if ((fgbg == 0) || (getChar(r, i) == ' ')) // If mode is foreground or a space, replace the character with PlotChar
					setChar(r, i, plotChar);

				if ((i + d == c) && ((fgbg == 0) || (getChar(r, i + d) == ' '))) // Plot the last character if valid
					setChar(r, i + d, plotChar);
			}
		}
		// Vertical line plot
		if (dir == 1)
		{
			for (int i = r + distance; i != r; i += d)
			{
				if ((fgbg == 0) || (getChar(i, c) == ' '))
					setChar(i, c, plotChar);

				if ((i + d == r) && ((fgbg == 0) || (getChar(i + d, c) == ' ')))
					setChar(i + d, c, plotChar);
			}
		}
		return true;
	}
}
int performCommands(string commandString, char& plotChar, int& mode, int& badPos)
{
	int pos = 0;
	int rowpos = 1;
	int colpos = 1;
	int temp = 0;
	int to_int = '0';
	int size = commandString.size()-1;

	// If there is no input in commandString, just plot the grid as it was before
	if (commandString.size() == 0)
	{
		return 0;
	}

	// Stops when the position to be examined exceeds commandString size minus one
	while (pos <= size)
	{
	
		// Horizontal Line
		if (commandString[pos] == 'H' || commandString[pos] == 'h')
		{
			if (commandString[pos + 1] == '-') // For negative distance
			{
				if (isdigit(commandString[pos + 2])) // Check if valid digit
				{
					if (isdigit(commandString[pos + 3])) // Check for 2 digit distance
					{
						temp = commandString[pos + 3] - to_int; // Conversion of char to int 
						temp = (((commandString[pos + 2] - to_int) * 10) + temp) * -1;
						if ((colpos + temp <= 0) || (colpos + temp > getCols())) // Check if the line produced exceeds the grid boundaries
						{
							badPos = pos;
							return 2;
						}
						pos += 4;
					}
					else // Only 1 digit distance
					{
						temp = (commandString[pos + 2] - to_int) * -1;
						if ((colpos + temp <= 0) || (colpos + temp > getCols()))
						{
							badPos = pos;
							return 2;
						}
						pos += 3;
					}
				}
				else // If there are no valid digits the badPos is 2 characters away from pos
				{
					badPos = pos + 2;
					return 1;
				}
			}
			else if (isdigit(commandString[pos + 1])) // For positive distance
			{
				if (isdigit(commandString[pos + 2])) // Check for 2 digit distance
				{
					temp = commandString[pos + 2] - to_int;
					temp = ((commandString[pos + 1] - to_int) * 10) + temp;
					if ((colpos + temp <= 0) || (colpos + temp > getCols())) // Grid boundary
					{
						badPos = pos;
						return 2;
					}
					pos += 3;
				}
				else // For 1 digit distance
				{
					temp = commandString[pos + 1] - to_int;
					if ((colpos + temp <= 0) || (colpos + temp > getCols())) // Grid boundary
					{
						badPos = pos;
						return 2;
					}
					pos += 2;
				}
			}
			else // If there are no valid digits the badPos is 1 character away from pos
			{
				badPos = pos + 1;
				return 1;
			}
			plotLine(rowpos, colpos, temp, 0, plotChar, mode); // Plot the line using temp as distance
			colpos += temp; // Update position
			temp = 0; // Reset temp
		}

		// Vertical Line
		else if (commandString[pos] == 'V' || commandString[pos] == 'v')
		{
			if (commandString[pos + 1] == '-') // Negative distance
			{
				if (isdigit(commandString[pos + 2])) 
				{
					if (isdigit(commandString[pos + 3])) // 2 digit distance
					{
						temp = commandString[pos + 3] - to_int;
						temp = (((commandString[pos + 2] - to_int) * 10) + temp) * -1;
						if ((rowpos + temp <= 0) || (rowpos + temp > getRows())) // Grid boundary
						{
							badPos = pos;
							return 2;
						}
						pos += 4;
					}
					else // 1 digit distance
					{
						temp = (commandString[pos + 2] - to_int) * -1;
						if ((rowpos + temp <= 0) || (rowpos + temp > getRows())) // Grid boundary
						{
							badPos = pos;
							return 2;
						}
						pos += 3;

					}
				}
				else // If there are no valid digits, badPos must be 2 characters away
				{
					badPos = pos + 2;
					return 1;
				}
			}
			else if (isdigit(commandString[pos + 1])) // Positive distance
			{
				if (isdigit(commandString[pos + 2])) // 2 digit distance
				{
					temp = commandString[pos + 2] - to_int;
					temp = ((commandString[pos + 1] - to_int) * 10) + temp;
					if ((rowpos + temp <= 0) || (rowpos + temp > getRows())) // Grid boundary
					{
						badPos = pos;
						return 2;
					}
					pos += 3;
				}
				else // 1 digit distance
				{
					temp = commandString[pos + 1] - to_int;
					if ((rowpos + temp <= 0) || (rowpos + temp > getRows()))
					{
						badPos = pos;
						return 2;
					}
					pos += 2;
				}
			}
			else // badPos must be one character away
			{
				badPos = pos + 1;
				return 1;
			}
			plotLine(rowpos, colpos, temp, 1, plotChar, mode); // Plot line if no errors
			rowpos += temp; // Update row position
			temp = 0; // Reset temp
		}

		// Foreground
		else if ((commandString[pos] == 'F') || (commandString[pos] == 'f'))
		{
			mode = 0; // Change mode to foreground
			if (!isprint(commandString[pos + 1])) // Valid character or not
			{
				badPos = pos + 1;
				return 1;
			}
			else // If valid character
			{
				plotChar = commandString[pos + 1];
				pos += 2;
			}
		}

		// Background
		else if ((commandString[pos] == 'B') || (commandString[pos] == 'b'))
		{
			mode = 1; // Change mode to background
			if (!isprint(commandString[pos + 1])) // Valid character or not
			{
				badPos = pos + 1;
				return 1;
			}
			else // If valid character
			{
				plotChar = commandString[pos + 1];
				pos += 2;
			}
		}

		// Clear
		else if ((commandString[pos] == 'C') || (commandString[pos] == 'c'))
		{
			clearGrid(); // Clear grid
			// Reset position
			colpos = 1; 
			rowpos = 1;
			plotChar = '*'; // Reset character
			pos += 1;
		}

		// Syntatical Error
		else
		{
			badPos = pos;
			return 1;
		}
	}
	return 0; // Return 0 (success in switch statement) if the while loop was successfully run through 
}



